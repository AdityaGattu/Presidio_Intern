package controlpack;

public interface TelcoSayHello {
	public String sayHello();
}
