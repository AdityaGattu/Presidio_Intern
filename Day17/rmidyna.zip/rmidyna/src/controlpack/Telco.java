package controlpack;

public class Telco implements TelcoSayHello{
	public String sayHello() {
		return "Welcome to the Next Generation Telecom application....";
	}
}
