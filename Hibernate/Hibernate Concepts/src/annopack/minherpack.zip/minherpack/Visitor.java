package annopack.minherpack;

public interface Visitor {
	public void process(Automobile bsf);
	public void process(Maruti lsf);
	public void process(Car sf);
}
